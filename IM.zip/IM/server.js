const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const STORAGE_PATH = path.join(__dirname, "quizResults.json");

const careerLibrary = {
  A: [
    { title: "Software Developer", description: "Build and develop software applications.", skills: ["Coding", "Problem Solving"] },
    { title: "Data Scientist", description: "Analyze data and uncover insights.", skills: ["Statistics", "Analytics"] },
    { title: "Web Developer", description: "Create engaging websites and online tools.", skills: ["HTML/CSS", "JavaScript"] }
  ],
  B: [
    { title: "Doctor", description: "Treat patients and provide medical care.", skills: ["Diagnosis", "Care"] },
    { title: "Nurse", description: "Support patient treatment and recovery.", skills: ["Patient Care", "Teamwork"] },
    { title: "Psychologist", description: "Guide people through mental health and wellbeing.", skills: ["Listening", "Counseling"] }
  ],
  C: [
    { title: "Manager", description: "Lead teams and manage business operations.", skills: ["Planning", "Leadership"] },
    { title: "Entrepreneur", description: "Launch new ideas and build businesses.", skills: ["Vision", "Resilience"] },
    { title: "Marketing Specialist", description: "Promote brands with effective campaigns.", skills: ["Strategy", "Communication"] }
  ],
  D: [
    { title: "Graphic Designer", description: "Design visuals for digital and print media.", skills: ["Creativity", "Typography"] },
    { title: "Animator", description: "Bring stories to life with motion and design.", skills: ["Animation", "Storytelling"] },
    { title: "Content Creator", description: "Produce engaging content for audiences.", skills: ["Writing", "Video Editing"] }
  ]
};

const categoryNames = {
  A: "Tech",
  B: "Healthcare",
  C: "Business",
  D: "Creative"
};

function ensureStorage() {
  if (!fs.existsSync(STORAGE_PATH)) {
    fs.writeFileSync(STORAGE_PATH, "[]", "utf8");
  }
}

function saveResult(record) {
  try {
    ensureStorage();
    const raw = fs.readFileSync(STORAGE_PATH, "utf8") || "[]";
    const data = JSON.parse(raw);
    data.push(record);
    fs.writeFileSync(STORAGE_PATH, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    console.error("Unable to save quiz result:", error);
  }
}

app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname)));

const defaultRecommendations = [
  { title: "Software Developer", description: "Build and develop software applications.", skills: ["Coding", "Problem Solving"] },
  { title: "Doctor", description: "Treat patients and provide medical care.", skills: ["Diagnosis", "Care"] },
  { title: "Manager", description: "Lead teams and manage business operations.", skills: ["Planning", "Leadership"] }
];

app.post("/api/recommend", (req, res) => {
  console.log("REQ BODY:", req.body);
  const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];

  if (answers.length === 0) {
    return res.json({ success: true, topCategory: "Default", recommendations: defaultRecommendations });
  }

  const validAnswers = answers.every(answer => ["A", "B", "C", "D"].includes(answer));
  if (!validAnswers) {
    return res.json({ success: true, topCategory: "Default", recommendations: defaultRecommendations });
  }

  const scores = answers.reduce((acc, answer) => {
    acc[answer] = (acc[answer] || 0) + 1;
    return acc;
  }, { A: 0, B: 0, C: 0, D: 0 });

  const sortedCategories = Object.entries(scores)
    .sort(([, a], [, b]) => b - a)
    .map(([category]) => category);

  const topCategory = sortedCategories[0];
  const secondCategory = sortedCategories[1];

  const recommendations = [
    ...careerLibrary[topCategory].slice(0, 3),
    ...careerLibrary[secondCategory].slice(0, 2)
  ];

  const result = {
    success: true,
    topCategory: categoryNames[topCategory],
    recommendations
  };

  saveResult({
    answers,
    topCategory: categoryNames[topCategory],
    recommendations,
    createdAt: new Date().toISOString()
  });

  res.json(result);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
