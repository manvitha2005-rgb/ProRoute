const quizData = [
  {
    question: "What do you enjoy most?",
    options: [
      { label: "Coding", value: "A" },
      { label: "Helping people", value: "B" },
      { label: "Managing tasks", value: "C" },
      { label: "Designing", value: "D" }
    ]
  },
  {
    question: "What type of work do you prefer?",
    options: [
      { label: "Logical problem-solving", value: "A" },
      { label: "Caring for others", value: "B" },
      { label: "Leading teams", value: "C" },
      { label: "Creative work", value: "D" }
    ]
  },
  {
    question: "Which environment feels best?",
    options: [
      { label: "Fast-paced tech", value: "A" },
      { label: "Patient support", value: "B" },
      { label: "Office leadership", value: "C" },
      { label: "Studio or agency", value: "D" }
    ]
  },
  {
    question: "What skill do you enjoy using?",
    options: [
      { label: "Analyzing data", value: "A" },
      { label: "Listening and advising", value: "B" },
      { label: "Organizing resources", value: "C" },
      { label: "Visual storytelling", value: "D" }
    ]
  },
  {
    question: "What motivates you most?",
    options: [
      { label: "Building software", value: "A" },
      { label: "Improving health", value: "B" },
      { label: "Growing a business", value: "C" },
      { label: "Creating content", value: "D" }
    ]
  },
  {
    question: "How do you solve problems?",
    options: [
      { label: "With systems and logic", value: "A" },
      { label: "With empathy and care", value: "B" },
      { label: "With planning and direction", value: "C" },
      { label: "With imagination and design", value: "D" }
    ]
  },
  {
    question: "What do you value most in a job?",
    options: [
      { label: "Innovation and technology", value: "A" },
      { label: "Making a difference", value: "B" },
      { label: "Achievement and success", value: "C" },
      { label: "Freedom and expression", value: "D" }
    ]
  },
  {
    question: "How do you prefer to spend your free time?",
    options: [
      { label: "Learning new tech", value: "A" },
      { label: "Volunteering or helping", value: "B" },
      { label: "Planning projects", value: "C" },
      { label: "Creating art or media", value: "D" }
    ]
  }
];

const careers = {
  A: [
    { title: "Software Developer", description: "Build web and mobile applications using modern tools.", skills: ["Programming", "Debugging", "Teamwork"] },
    { title: "Data Scientist", description: "Analyze data to reveal trends and improve decisions.", skills: ["Statistics", "Modeling", "Problem-solving"] },
    { title: "Web Developer", description: "Create responsive websites and interactive online experiences.", skills: ["HTML/CSS", "JavaScript", "UI design"] }
  ],
  B: [
    { title: "Doctor", description: "Care for patients and diagnose medical conditions.", skills: ["Communication", "Knowledge", "Empathy"] },
    { title: "Nurse", description: "Support medical teams and assist patients daily.", skills: ["Patient care", "Attention", "Teamwork"] },
    { title: "Psychologist", description: "Help people improve mental health and wellbeing.", skills: ["Active listening", "Insight", "Support"] }
  ],
  C: [
    { title: "Business Manager", description: "Supervise teams, resources, and strategic goals.", skills: ["Leadership", "Planning", "Communication"] },
    { title: "Entrepreneur", description: "Start new ideas and grow businesses with passion.", skills: ["Decision-making", "Resilience", "Creativity"] },
    { title: "Marketing Specialist", description: "Promote brands and launch campaigns that connect.", skills: ["Messaging", "Analytics", "Storytelling"] }
  ],
  D: [
    { title: "Graphic Designer", description: "Design visual concepts for print and digital media.", skills: ["Creativity", "Typography", "Layout"] },
    { title: "Animator", description: "Create motion graphics and stories in animation format.", skills: ["Animation", "Storytelling", "Software"] },
    { title: "Content Creator", description: "Produce engaging media for audiences and brands.", skills: ["Writing", "Video editing", "Creativity"] }
  ]
};

const state = {
  currentIndex: 0,
  answers: Array(quizData.length).fill(null)
};

const authPage = document.getElementById("authPage");
const registerForm = document.getElementById("registerForm");
const loginForm = document.getElementById("loginForm");
const showRegister = document.getElementById("showRegister");
const showLogin = document.getElementById("showLogin");
const authMessage = document.getElementById("authMessage");
const registerName = document.getElementById("registerName");
const registerEmail = document.getElementById("registerEmail");
const loginInput = document.getElementById("loginInput");
const rememberMe = document.getElementById("rememberMe");
const logoutBtn = document.getElementById("logoutBtn");
const headerEl = document.querySelector(".site-header");
const mainContent = document.querySelector("main");
const footerEl = document.querySelector(".site-footer");
const welcomeMessage = document.getElementById("welcomeMessage");
const questionPanel = document.getElementById("questionPanel");
const optionsGrid = document.getElementById("optionsGrid");
const progressFill = document.getElementById("progressFill");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const resultPanel = document.getElementById("resultPanel");
const loadingOverlay = document.getElementById("loadingOverlay");
const startTestBtn = document.getElementById("startTestBtn");
const themeToggle = document.getElementById("themeToggle");
const contactForm = document.getElementById("contactForm");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const messageInput = document.getElementById("messageInput");
const contactMessage = document.getElementById("contactMessage");

function getStoredUsers() {
  return JSON.parse(localStorage.getItem("careerGuideUsers") || "[]");
}

function saveUsers(users) {
  localStorage.setItem("careerGuideUsers", JSON.stringify(users));
}

function getLoggedInUser() {
  const remembered = localStorage.getItem("careerGuideLoggedIn");
  if (remembered) {
    return JSON.parse(remembered);
  }
  const sessionData = sessionStorage.getItem("careerGuideSession");
  return sessionData ? JSON.parse(sessionData) : null;
}

function setLoggedInUser(user, remember) {
  if (remember) {
    localStorage.setItem("careerGuideLoggedIn", JSON.stringify(user));
    sessionStorage.removeItem("careerGuideSession");
  } else {
    sessionStorage.setItem("careerGuideSession", JSON.stringify(user));
    localStorage.removeItem("careerGuideLoggedIn");
  }
}

function clearLoggedInUser() {
  localStorage.removeItem("careerGuideLoggedIn");
  sessionStorage.removeItem("careerGuideSession");
}

function sendContactMessage(event) {
  event.preventDefault();
  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const message = messageInput.value.trim();

  if (!name || !email || !message) {
    alert("Please fill in your name, email, and message before sending.");
    return;
  }

  if (!validateEmail(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  const sendData = {
    name,
    email,
    message,
    _subject: `CareerGuide Contact from ${name}`,
    _captcha: "false"
  };

  contactMessage.textContent = "Sending...";
  contactMessage.className = "contact-message info";

  fetch("https://formsubmit.co/ajax/manvithaa78@gmail.com", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json"
    },
    body: JSON.stringify(sendData)
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        contactMessage.textContent = "Thank You! Your message has been sent.";
        contactMessage.className = "contact-message success";
        contactForm.reset();
      } else {
        throw new Error(data.message || "Unable to send message.");
      }
    })
    .catch(() => {
      contactMessage.textContent = "Unable to send message right now. Please try again later.";
      contactMessage.className = "contact-message error";
    });
}

function switchAuthView(view) {
  authMessage.textContent = "";
  registerForm.classList.toggle("hidden", view !== "register");
  loginForm.classList.toggle("hidden", view !== "login");
  showRegister.classList.toggle("active", view === "register");
  showLogin.classList.toggle("active", view === "login");
}

function showAuthNotification(message, type = "error") {
  authMessage.textContent = message;
  authMessage.className = `auth-alert ${type}`;
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function registerUser(event) {
  event.preventDefault();
  const fullName = registerName.value.trim();
  const email = registerEmail.value.trim().toLowerCase();

  if (!fullName || !email) {
    showAuthNotification("All fields are required.", "error");
    return;
  }

  if (!validateEmail(email)) {
    showAuthNotification("Please enter a valid email address.", "error");
    return;
  }

  const users = getStoredUsers();
  const duplicate = users.some(user => user.email === email);

  if (duplicate) {
    showAuthNotification("This email is already registered.", "error");
    return;
  }

  users.push({ fullName, email });
  saveUsers(users);
  showAuthNotification("Registration Successful. Please login.", "success");
  registerForm.reset();
  switchAuthView("login");
}

function loginUser(event) {
  event.preventDefault();
  const input = loginInput.value.trim().toLowerCase();

  if (!input) {
    showAuthNotification("Full Name or Email ID is required.", "error");
    return;
  }

  const users = getStoredUsers();
  const user = users.find(userItem => userItem.email === input || userItem.fullName.toLowerCase() === input);

  if (!user) {
    showAuthNotification("User not found. Please register first.", "error");
    return;
  }

  setLoggedInUser(user, rememberMe.checked);
  renderLoggedInUser(user);
}

function renderLoggedInUser(user) {
  authPage.classList.add("hidden");
  headerEl.classList.remove("hidden");
  mainContent.classList.remove("hidden");
  footerEl.classList.remove("hidden");
  logoutBtn.classList.remove("hidden");
  welcomeMessage.textContent = `Welcome back, ${user.fullName}!`;
  welcomeMessage.classList.remove("hidden");
}

function logoutUser() {
  clearLoggedInUser();
  authPage.classList.remove("hidden");
  headerEl.classList.add("hidden");
  mainContent.classList.add("hidden");
  footerEl.classList.add("hidden");
  logoutBtn.classList.add("hidden");
  welcomeMessage.classList.add("hidden");
  switchAuthView("login");
  loginForm.reset();
}

function initAuth() {
  const currentUser = getLoggedInUser();
  if (currentUser) {
    renderLoggedInUser(currentUser);
  } else {
    authPage.classList.remove("hidden");
    headerEl.classList.add("hidden");
    mainContent.classList.add("hidden");
    footerEl.classList.add("hidden");
    logoutBtn.classList.add("hidden");
    switchAuthView("register");
  }
}

function renderQuestion() {
  const item = quizData[state.currentIndex];
  questionPanel.innerHTML = `<h3>Question ${state.currentIndex + 1} of ${quizData.length}</h3><p>${item.question}</p>`;

  optionsGrid.innerHTML = item.options.map(option => {
    const selected = state.answers[state.currentIndex] === option.value ? "active" : "";
    return `<button class="option-card ${selected}" data-value="${option.value}">${option.label}</button>`;
  }).join("");

  Array.from(optionsGrid.children).forEach(button => {
    button.addEventListener("click", () => selectOption(button.dataset.value));
  });

  progressFill.style.width = `${((state.currentIndex) / (quizData.length - 1)) * 100}%`;
  prevBtn.disabled = state.currentIndex === 0;
  nextBtn.textContent = state.currentIndex === quizData.length - 1 ? "See Results" : "Next";
}

function selectOption(value) {
  state.answers[state.currentIndex] = value;
  renderQuestion();
}

function previousQuestion() {
  if (state.currentIndex > 0) {
    state.currentIndex -= 1;
    renderQuestion();
  }
}

function nextQuestion() {
  if (!state.answers[state.currentIndex]) {
    alert("Please choose an option to continue.");
    return;
  }
  if (state.currentIndex < quizData.length - 1) {
    state.currentIndex += 1;
    renderQuestion();
    return;
  }
  submitQuiz();
}

async function submitQuiz() {
  loadingOverlay.classList.remove("hidden");
  prevBtn.disabled = true;
  nextBtn.disabled = true;
  resultPanel.innerHTML = "";

  // Calculate scores locally
  const scores = { A: 0, B: 0, C: 0, D: 0 };
  state.answers.forEach(answer => {
    if (answer) scores[answer]++;
  });

  // Sort categories by score descending
  const sortedCategories = Object.entries(scores)
    .sort(([,a], [,b]) => b - a)
    .map(([category]) => category);

  const topCategory = sortedCategories[0];
  const secondCategory = sortedCategories[1];

  // Get recommendations: 3 from top, 1-2 from second
  let recommendations = [];
  if (careers[topCategory]) {
    recommendations.push(...careers[topCategory].slice(0, 3));
  }
  if (careers[secondCategory] && scores[secondCategory] > 0) {
    const fromSecond = Math.min(2, careers[secondCategory].length);
    recommendations.push(...careers[secondCategory].slice(0, fromSecond));
  }

  const data = {
    success: true,
    topCategory: getCategoryName(topCategory),
    recommendations: recommendations
  };

  // Simulate async delay for UX
  setTimeout(() => {
    displayResults(data);
    loadingOverlay.classList.add("hidden");
  }, 1500);
}

function getCategoryName(code) {
  const names = { A: "Tech", B: "Healthcare", C: "Business", D: "Creative" };
  return names[code] || "General";
}

function buildResultCard(career) {
  return `
    <article class="result-card">
      <h3>${career.title}</h3>
      <p>${career.description}</p>
      <small>Required Skills:</small>
      <ul>${career.skills.map(skill => `<li>${skill}</li>`).join("")}</ul>
      <button class="secondary-btn learn-more-btn" data-role="${career.title}">Learn More</button>
    </article>
  `;
}

function displayResults(data) {
  const topCategory = data.topCategory;
  const selectedResults = Array.isArray(data.recommendations) ? data.recommendations : [];
  const message = data.message ? `<p class="status-note">${data.message}</p>` : "";

  resultPanel.innerHTML = `
    <div class="result-header">
      <h3>Your Career Recommendations</h3>
      ${message}
      <p>Top category: ${topCategory}. Here are careers matched to your strengths.</p>
      <button class="secondary-btn" id="retakeBtn">Retake Test</button>
    </div>
    <div class="results-grid">${selectedResults.map(buildResultCard).join("")}</div>
  `;

  const retakeBtn = document.getElementById("retakeBtn");
  retakeBtn.addEventListener("click", resetQuiz);

  const learnMoreButtons = resultPanel.querySelectorAll(".learn-more-btn");
  learnMoreButtons.forEach(button => {
    button.addEventListener("click", () => {
      const roleName = button.dataset.role || button.textContent;
      openRoleWiki(roleName);
    });
  });

  nextBtn.disabled = true;
  prevBtn.disabled = true;
  progressFill.style.width = "100%";
  resultPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

function openRoleWiki(roleName) {
  const query = `${roleName} Wikipedia`;
  const encoded = encodeURIComponent(query);
  const url = `https://www.google.com/search?q=${encoded}`;
  window.open(url, "_blank");
}

function showError(message) {
  resultPanel.innerHTML = `
    <div class="error-box">
      <h3>Something went wrong</h3>
      <p>${message}</p>
      <button class="secondary-btn" id="retryBtn">Try Again</button>
    </div>
  `;

  const retryBtn = document.getElementById("retryBtn");
  retryBtn.addEventListener("click", () => {
    resultPanel.innerHTML = "";
    resetQuiz();
  });
}

function resetQuiz() {
  state.currentIndex = 0;
  state.answers = Array(quizData.length).fill(null);
  resultPanel.innerHTML = "";
  nextBtn.disabled = false;
  prevBtn.disabled = false;
  renderQuestion();
}

showRegister.addEventListener("click", () => switchAuthView("register"));
showLogin.addEventListener("click", () => switchAuthView("login"));
registerForm.addEventListener("submit", registerUser);
loginForm.addEventListener("submit", loginUser);
logoutBtn.addEventListener("click", logoutUser);

if (contactForm) {
  contactForm.addEventListener("submit", sendContactMessage);
}

startTestBtn.addEventListener("click", () => {
  document.getElementById("quiz").scrollIntoView({ behavior: "smooth" });
});
prevBtn.addEventListener("click", previousQuestion);
nextBtn.addEventListener("click", nextQuestion);

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");
  themeToggle.textContent = document.body.classList.contains("dark-theme") ? "☀️" : "🌙";
});

initAuth();
renderQuestion();
