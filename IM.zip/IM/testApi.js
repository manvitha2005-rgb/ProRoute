const http = require('http');
const data = JSON.stringify({ answers: ['A','B','A','D','C','A'] });
const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/recommend',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};
const req = http.request(options, res => {
  let body = '';
  res.on('data', chunk => { body += chunk; });
  res.on('end', () => {
    console.log('STATUS', res.statusCode);
    console.log('CT', res.headers['content-type']);
    console.log('BODY', body);
    try {
      console.log('PARSED', JSON.parse(body));
    } catch (e) {
      console.error('PARSE_ERROR', e.message);
    }
  });
});
req.on('error', err => console.error('REQUEST_ERROR', err.message));
req.write(data);
req.end();
