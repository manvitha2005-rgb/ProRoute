# Career Recommendation Website

A fully functional, responsive career recommendation website with a Wix-style layout. Built with HTML, CSS, and JavaScript only - no backend required.

## Features

- Interactive 8-question career quiz
- Multiple career recommendations based on answers
- Smooth scrolling navigation
- Mobile responsive design
- Clean, minimal Wix-style UI

## How to Use

1. Open `index.html` in your web browser
2. Click "Start Test" to begin the quiz
3. Answer all 8 questions
4. View your personalized career recommendations

## Project Structure

- `index.html` - Main HTML structure
- `styles.css` - CSS styling with responsive design
- `script.js` - JavaScript for quiz logic and interactions

## What it does

- Frontend quiz collects 6 answers
- Sends answers to `POST /api/recommend`
- Backend calculates category scores and returns career recommendations
- Saves quiz results to `quizResults.json`
- Displays dynamic result cards without page reload
